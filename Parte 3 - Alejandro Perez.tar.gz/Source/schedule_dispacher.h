#ifndef __schedule_dispacher_h__
#define __schedule_dispacher_h__
void* schedule_dispacher_func_prueba(void* argument);
void* schedule_dispacher_function(void* argument);
#endif
