#ifndef __timer_h__
#define __timer_h__
void* timer_func_prueba(void* argument);
void* timer_function(void * indice_frec);
#endif
