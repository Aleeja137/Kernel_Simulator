#ifndef __process_generator_h__
#define __process_generator_h__er_h__
void* process_generator_func_prueba(void* argument);
void* process_generator_function(void* argument);
#endif
