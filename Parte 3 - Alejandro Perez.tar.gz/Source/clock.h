#ifndef __clock_h__
#define __clock_h__
void* clock_func_prueba(void* argument);
void* clock_function(void* argument);
void* reducirTtl(void* argument);
#endif
