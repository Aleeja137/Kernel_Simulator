#ifndef __process_generator_h__
#define __process_generator_h__er_h__
void* loader_func_prueba(void* argument);
void* loader_function(void* argument);
#endif
